import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {
    const [file, setFile] = useState(null);
    const [query, setQuery] = useState("");
    const [history, setHistory] = useState([]);
    const [isFileUploaded, setIsFileUploaded] = useState(false);

    // File upload handler
    const handleFileUpload = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("uploaded_file", file);

        try {
            await axios.post("http://localhost:8000/ingest", formData, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            setIsFileUploaded(true);
            alert("File uploaded and processed successfully!");
        } catch (error) {
            console.error("Error uploading file:", error);
        }
    };

    // Chat submit handler
    const handleChatSubmit = async (e) => {
        e.preventDefault();
        const newHistory = [...history, { user: query }];

        try {
            const response = await axios.post("http://localhost:8000/chat", {
                query,
                history: history.map((item) => item.user),
            });

            setHistory([...newHistory, { bot: response.data.answer }]);
            setQuery(""); // Clear input field
        } catch (error) {
            console.error("Error in chat query:", error);
        }
    };

    return (
        <div className="App">
            <h1>Chat with PDF Data</h1>

            {/* File Upload Section */}
            <div className="file-upload">
                <form onSubmit={handleFileUpload}>
                    <input
                        type="file"
                        onChange={(e) => setFile(e.target.files[0])}
                        className="file-input"
                    />
                    <button type="submit" className="upload-btn">
                        Upload PDF
                    </button>
                </form>
            </div>

            {/* Chat Interface */}
            {isFileUploaded && (
                <div className="chat-container">
                    <form onSubmit={handleChatSubmit} className="chat-form">
                        <input
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Ask me anything..."
                            className="chat-input"
                        />
                        <button type="submit" className="send-btn">Send</button>
                    </form>

                    {/* Chat History Display */}
                    <div className="chat-history">
                        {history.map((message, index) => (
                            <div key={index} className={`message ${message.user ? "user" : "bot"}`}>
                                <div className="message-content">{message.user || message.bot}</div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default App;
