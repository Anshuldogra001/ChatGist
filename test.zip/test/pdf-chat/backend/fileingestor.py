from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from langchain_community.document_loaders import PyMuPDFLoader
from loadllm import Loadllm
import tempfile
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from pydantic import BaseModel
import tempfile
import os

app = FastAPI()

# CORS to allow React to communicate with FastAPI
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_FAISS_PATH = 'vectorstore/db_faiss'

class QueryModel(BaseModel):
    query: str
    history: list

# Endpoint to upload and process PDF file
@app.post("/ingest")
async def ingest_file(uploaded_file: UploadFile = File(...)):
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(await uploaded_file.read())
        tmp_file_path = tmp_file.name

    loader = PyMuPDFLoader(file_path=tmp_file_path)
    data = loader.load()

    # Create embeddings and save in FAISS vector store
    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    db = FAISS.from_documents(data, embeddings)
    db.save_local(DB_FAISS_PATH)

    os.remove(tmp_file_path)
    return {"message": "File processed successfully"}

# Endpoint to handle chat
@app.post("/chat")
async def chat(query: QueryModel):
    # Load FAISS vector store and language model
    db = FAISS.load_local(DB_FAISS_PATH, embeddings=HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2'), allow_dangerous_deserialization=True)
    llm = Loadllm.load_llm()
    chain = ConversationalRetrievalChain.from_llm(llm=llm, retriever=db.as_retriever())

    # Process chat query
    result = chain({"question": query.query, "chat_history": query.history})
    return {"answer": result["answer"]}